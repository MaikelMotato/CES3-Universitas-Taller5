package co.edu.poli.ces3.universitas.enrollment;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/enrollments")
public class EnrollmentController {

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @PatchMapping
    public ResponseEntity<?> updateEnrollment(@RequestParam Long idUser, @RequestBody Map<String, Object> updates) {
        Optional<Enrollment> optionalEnrollment = enrollmentRepository.findById(idUser);
        if (optionalEnrollment.isPresent()) {
            Enrollment enrollment = optionalEnrollment.get();
            updates.forEach((key, value) -> {
                Field field = ReflectionUtils.findField(Enrollment.class, key);
                field.setAccessible(true);
                ReflectionUtils.setField(field, enrollment, value);
            });
            enrollmentRepository.save(enrollment);
            return ResponseEntity.ok(enrollment);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}

