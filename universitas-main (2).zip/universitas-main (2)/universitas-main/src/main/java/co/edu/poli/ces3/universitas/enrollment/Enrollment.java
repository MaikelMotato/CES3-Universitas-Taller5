package co.edu.poli.ces3.universitas.enrollment;

@Entity
public class Enrollment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String courseName;
    private String semester;
    private String status;

}

