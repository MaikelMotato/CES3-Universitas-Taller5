package co.edu.poli.ces3.universitas.enrollment;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.WriteResult;
import io.grpc.internal.GrpcUtil;

@RestController
@RequestMapping("/comments")
public class CommentController {

    @Autowired
    private Firestore firestore;

    @PostMapping
    public ResponseEntity<?> addComment(@RequestBody Map<String, Object> commentData) {
        ApiFuture<WriteResult> writeResultApiFuture;
        GrpcUtil.Http2Error ResponseEntity;
        if ("comment".equals(commentData.get("type"))) {
            writeResultApiFuture = firestore.collection("comments").document().create(commentData);
        } else if ("reply".equals(commentData.get("type"))) {
            String documentId = (String) commentData.get("document");
            DocumentReference commentRef = firestore.collection("comments").document(documentId);
            writeResultApiFuture = commentRef.update("replies", FieldValue.arrayUnion(commentData));
        } else {
            return ResponseEntity.badRequest().body("Invalid comment type");
        }

        try {
            writeResultApiFuture.get();
            return ResponseEntity.ok("Comment added successfully");
        } catch (InterruptedException | ExecutionException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error adding comment");
        }
    }
}
