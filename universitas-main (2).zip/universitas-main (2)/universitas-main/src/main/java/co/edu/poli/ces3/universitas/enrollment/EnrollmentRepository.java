package co.edu.poli.ces3.universitas.enrollment;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
}
