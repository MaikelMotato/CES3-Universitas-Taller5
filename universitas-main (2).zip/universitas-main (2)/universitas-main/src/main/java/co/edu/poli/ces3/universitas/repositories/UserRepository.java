package co.edu.poli.ces3.universitas.repositories;

import co.edu.poli.ces3.universitas.dao.User;
import co.edu.poli.ces3.universitas.database.ConexionMySql;
import co.edu.poli.ces3.universitas.database.Crud;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserRepository extends ConexionMySql implements Crud<User> {

    @Override
    public void insert(User user) {
        String sql = "INSERT INTO users (name, lastName, mail, password, createdAt, updatedAt, deletedAt) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try {
            createConexion();
            PreparedStatement stmt = getCnn().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, user.getName());
            stmt.setString(2, user.getLastName());
            stmt.setString(3, user.getMail());
            stmt.setString(4, user.getPassword());
            stmt.setDate(5, new java.sql.Date(user.getCreatedAt().getTime()));
            stmt.setDate(6, new java.sql.Date(user.getUpdatedAt().getTime()));
            stmt.setDate(7, user.getDeletedAt() != null ? new java.sql.Date(user.getDeletedAt().getTime()) : null);

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    user.setId(generatedKeys.getInt(1));
                }
            }
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (getCnn() != null) getCnn().close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public User getUserByEmail(String email) {
        String sql = "SELECT * FROM users WHERE mail = ?";
        User user = null;
        try {
            createConexion();
            PreparedStatement stmt = getCnn().prepareStatement(sql);
            stmt.setString(1, email);
            ResultSet result = stmt.executeQuery();
            if (result.next()) {
                user = new User(
                        result.getInt("id"),
                        result.getString("name"),
                        result.getString("lastName"),
                        result.getString("mail"),
                        result.getString("password"),
                        result.getDate("createdAt"),
                        result.getDate("updatedAt"),
                        result.getDate("deletedAt")
                );
            }
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (getCnn() != null) getCnn().close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return user;
    }

    @Override
    public void update(User user) {

    }

    @Override
    public List<User> get() throws SQLException {
        String sql = "SELECT * FROM users";
        List<User> list = new ArrayList<>();
        try {
            createConexion();
            Statement stmt = getCnn().createStatement();
            ResultSet result = stmt.executeQuery(sql);
            while (result.next()) {
                list.add(new User(
                        result.getInt("id"),
                        result.getString("name"),
                        result.getString("lastName"),
                        result.getString("mail"),
                        result.getString("password"),
                        result.getDate("createdAt"),
                        result.getDate("updatedAt"),
                        result.getDate("deletedAt")
                ));
            }
            stmt.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (getCnn() != null)
                getCnn().close();
        }
        return list;
    }

    @Override
    public User getOne(int id) throws SQLException {
        String sql = "SELECT * FROM users WHERE id = ?";
        User user = null;
        try {
            createConexion();
            PreparedStatement stmt = getCnn().prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet result = stmt.executeQuery();
            if (result.next()) {
                user = new User(
                        result.getInt("id"),
                        result.getString("name"),
                        result.getString("lastName"),
                        result.getString("mail"),
                        result.getString("password"),
                        result.getDate("createdAt"),
                        result.getDate("updatedAt"),
                        result.getDate("deletedAt")
                );
            }
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (getCnn() != null)
                getCnn().close();
        }
        return user;
    }
}
